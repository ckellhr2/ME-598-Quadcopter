"""Plotting utilities for trajectories and the learning curve."""

from __future__ import annotations
import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D   # noqa: F401 (registers 3d projection)


STATE_LABELS = [
    'x [m]', 'y [m]', 'z [m]',
    'vx [m/s]', 'vy [m/s]', 'vz [m/s]',
    'φ [deg]', 'θ [deg]', 'ψ [deg]',
    'p [deg/s]', 'q [deg/s]', 'r [deg/s]',
]


def plot_trajectory(
    X: np.ndarray,
    U: np.ndarray,
    x_goal: np.ndarray,
    dt: float,
    title: str = 'iLQR Trajectory',
    save_path: str | None = 'trajectory.png',
) -> plt.Figure:
    """
    Six-panel summary:  3-D path | positions | velocities |
                        Euler angles | angular rates | motor thrusts.
    """
    N = U.shape[0]
    t = np.arange(N + 1) * dt

    # Convert angles to degrees for readability
    X_plot       = X.copy()
    X_plot[:, 6:12] = np.degrees(X[:, 6:12])
    g_deg        = np.degrees(x_goal[6:12])

    fig = plt.figure(figsize=(17, 10))
    fig.suptitle(title, fontsize=13, y=0.99)

    # --- 3-D trajectory ---
    ax3d = fig.add_subplot(2, 3, 1, projection='3d')
    ax3d.plot(X[:, 0], X[:, 1], X[:, 2], 'b-', lw=1.5, label='traj')
    ax3d.scatter(*X[0,  :3], s=60, c='green',  zorder=5, label='start')
    ax3d.scatter(*x_goal[:3], s=80, c='red', marker='*', zorder=5, label='goal')
    ax3d.set_xlabel('x'); ax3d.set_ylabel('y'); ax3d.set_zlabel('z')
    ax3d.set_title('3-D Path')
    ax3d.legend(fontsize=8)

    # --- position ---
    ax2 = fig.add_subplot(2, 3, 2)
    for i, (c, lbl) in enumerate(zip('rgb', ['x', 'y', 'z'])):
        ax2.plot(t, X_plot[:, i], color=c, label=lbl)
        ax2.axhline(x_goal[i], color=c, ls='--', alpha=0.45)
    ax2.set_title('Position'); ax2.set_xlabel('t [s]'); ax2.set_ylabel('[m]')
    ax2.legend(); ax2.grid(True, alpha=0.3)

    # --- velocity ---
    ax3 = fig.add_subplot(2, 3, 3)
    for i, lbl in enumerate(['vx', 'vy', 'vz']):
        ax3.plot(t, X_plot[:, 3 + i], label=lbl)
    ax3.set_title('Velocity'); ax3.set_xlabel('t [s]'); ax3.set_ylabel('[m/s]')
    ax3.legend(); ax3.grid(True, alpha=0.3)

    # --- Euler angles ---
    ax4 = fig.add_subplot(2, 3, 4)
    for i, lbl in enumerate(['φ', 'θ', 'ψ']):
        ax4.plot(t, X_plot[:, 6 + i], label=lbl)
        ax4.axhline(g_deg[i], ls='--', alpha=0.35)
    ax4.set_title('Euler Angles'); ax4.set_xlabel('t [s]'); ax4.set_ylabel('[deg]')
    ax4.legend(); ax4.grid(True, alpha=0.3)

    # --- angular rates ---
    ax5 = fig.add_subplot(2, 3, 5)
    for i, lbl in enumerate(['p', 'q', 'r']):
        ax5.plot(t, X_plot[:, 9 + i], label=lbl)
    ax5.set_title('Angular Rates'); ax5.set_xlabel('t [s]'); ax5.set_ylabel('[deg/s]')
    ax5.legend(); ax5.grid(True, alpha=0.3)

    # --- motor thrusts ---
    ax6 = fig.add_subplot(2, 3, 6)
    for i in range(4):
        ax6.plot(t[:-1], U[:, i], label=f'f{i+1}')
    ax6.axhline(0,                    ls=':', color='k', alpha=0.4)
    ax6.set_title('Motor Thrusts'); ax6.set_xlabel('t [s]'); ax6.set_ylabel('[N]')
    ax6.legend(); ax6.grid(True, alpha=0.3)

    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Trajectory plot saved → {save_path}")
    return fig


def plot_learning_curve(
    history: list[float],
    save_path: str | None = 'learning_curve.png',
) -> plt.Figure:
    """Plot optimizer cost vs. generation / iteration."""
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(history, 'b-o', ms=4)
    ax.set_xlabel('Generation / Iteration')
    ax.set_ylabel('Best objective value')
    ax.set_title('Offline Learning Curve')
    ax.grid(True, alpha=0.35)
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Learning curve saved   → {save_path}")
    return fig
