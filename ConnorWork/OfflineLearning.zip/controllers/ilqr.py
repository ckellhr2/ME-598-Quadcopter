"""
Iterative Linear Quadratic Regulator (iLQR) for the quadcopter.

Minimises the finite-horizon cost:

    J = Σ_{k=0}^{N-1}  ½(x_k−x_g)ᵀ Q (x_k−x_g) + ½(u_k−u_g)ᵀ R (u_k−u_g)
        + ½(x_N−x_g)ᵀ Qf (x_N−x_g)

Algorithm (Tassa et al. 2012):
  1. Forward rollout from x0 with current controls U.
  2. Backward pass: linearise dynamics at each step, solve coupled Riccati
     equations to obtain feedback gains K_k and feedforward directions d_k.
  3. Forward pass with Armijo line search to find step length α.
  4. Repeat until convergence.
"""

from __future__ import annotations

import numpy as np
from typing import Optional

from quadcopter.dynamics import QuadcopterParams, rk4_step, linearize


class iLQR:
    """iLQR solver for the quadcopter system."""

    def __init__(self, params: QuadcopterParams, dt: float, N: int):
        self.params = params
        self.dt     = dt
        self.N      = N
        self.n      = 12   # state dimension
        self.m      = 4    # control dimension

    # ------------------------------------------------------------------
    # Rollout
    # ------------------------------------------------------------------

    def rollout(self, x0: np.ndarray, U: np.ndarray) -> np.ndarray:
        """Simulate the trajectory x_{0:N} from initial state x0."""
        X      = np.empty((self.N + 1, self.n))
        X[0]   = x0
        for k in range(self.N):
            u_k      = np.clip(U[k], self.params.f_min, self.params.f_max)
            X[k + 1] = rk4_step(X[k], u_k, self.dt, self.params)
        return X

    # ------------------------------------------------------------------
    # Cost
    # ------------------------------------------------------------------

    def _stage_cost(self, x, u, xg, ug, Q, R) -> float:
        dx = x - xg
        du = u - ug
        return 0.5 * (dx @ Q @ dx + du @ R @ du)

    def _terminal_cost(self, x, xg, Qf) -> float:
        dx = x - xg
        return 0.5 * (dx @ Qf @ dx)

    def total_cost(self, X, U, xg, ug, Q, R, Qf) -> float:
        J = sum(self._stage_cost(X[k], U[k], xg, ug, Q, R)
                for k in range(self.N))
        return J + self._terminal_cost(X[-1], xg, Qf)

    # ------------------------------------------------------------------
    # Backward pass
    # ------------------------------------------------------------------

    def _backward_pass(
        self,
        X: np.ndarray,
        U: np.ndarray,
        xg: np.ndarray,
        ug: np.ndarray,
        Q: np.ndarray,
        R: np.ndarray,
        Qf: np.ndarray,
        mu: float,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Compute feedback gains K (N×m×n) and feedforward directions d (N×m).

        Returns (K, d, dV) where dV[0], dV[1] are the linear and quadratic
        expected cost-reduction terms used for the line-search condition.
        """
        n, m = self.n, self.m

        # Terminal boundary conditions
        Vx  = Qf @ (X[-1] - xg)
        Vxx = Qf.copy()

        K  = np.empty((self.N, m, n))
        d  = np.empty((self.N, m))
        dV = np.zeros(2)

        reg = mu * np.eye(m)

        for k in range(self.N - 1, -1, -1):
            u_k    = np.clip(U[k], self.params.f_min, self.params.f_max)
            A, B   = linearize(X[k], u_k, self.dt, self.params)

            dx = X[k]   - xg
            du = U[k]   - ug

            # Action-value function derivatives
            Qx  = Q @ dx  + A.T @ Vx
            Qu  = R @ du  + B.T @ Vx
            Qxx = Q       + A.T @ Vxx @ A
            Quu = R       + B.T @ Vxx @ B  + reg
            Qux = B.T @ Vxx @ A

            # Gains (Quu must be positive-definite after regularisation)
            Quu_inv  = np.linalg.solve(Quu, np.eye(m))
            K[k]     = -Quu_inv @ Qux
            d[k]     = -Quu_inv @ Qu

            # Value function update
            Vx  = (Qx
                   + K[k].T @ Quu @ d[k]
                   + K[k].T @ Qu
                   + Qux.T  @ d[k])
            Vxx = (Qxx
                   + K[k].T @ Quu @ K[k]
                   + K[k].T @ Qux
                   + Qux.T  @ K[k])
            Vxx = 0.5 * (Vxx + Vxx.T)       # enforce symmetry

            dV[0] += d[k] @ Qu
            dV[1] += 0.5 * d[k] @ Quu @ d[k]

        return K, d, dV

    # ------------------------------------------------------------------
    # Forward pass
    # ------------------------------------------------------------------

    def _forward_pass(
        self,
        X: np.ndarray,
        U: np.ndarray,
        K: np.ndarray,
        d: np.ndarray,
        alpha: float,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Apply gains with step length α and re-simulate."""
        X_new    = np.empty_like(X)
        U_new    = np.empty_like(U)
        X_new[0] = X[0]

        for k in range(self.N):
            delta_x    = X_new[k] - X[k]
            U_new[k]   = np.clip(
                U[k] + K[k] @ delta_x + alpha * d[k],
                self.params.f_min,
                self.params.f_max,
            )
            X_new[k+1] = rk4_step(X_new[k], U_new[k], self.dt, self.params)

        return X_new, U_new

    # ------------------------------------------------------------------
    # Main solver
    # ------------------------------------------------------------------

    def solve(
        self,
        x0: np.ndarray,
        x_goal: np.ndarray,
        u_goal: np.ndarray,
        Q:  np.ndarray,
        R:  np.ndarray,
        Qf: np.ndarray,
        U_init: Optional[np.ndarray] = None,
        max_iter: int = 100,
        tol: float = 1e-4,
        verbose: bool = False,
    ) -> tuple[np.ndarray, np.ndarray, dict]:
        """
        Run iLQR to convergence.

        Parameters
        ----------
        x0      : initial state (12,)
        x_goal  : goal state    (12,)
        u_goal  : nominal control (hover) (4,)
        Q, R, Qf: cost matrices
        U_init  : initial control guess (N×4); defaults to u_goal repeated
        max_iter: maximum iLQR iterations
        tol     : convergence threshold on |ΔJ|
        verbose : print per-iteration cost

        Returns
        -------
        X    : optimal state trajectory  (N+1 × 12)
        U    : optimal control sequence  (N   × 4)
        info : dict with keys 'converged', 'iterations', 'cost'
        """
        # Initialise controls and simulate
        U = (np.tile(u_goal, (self.N, 1)) if U_init is None
             else U_init.copy())
        X = self.rollout(x0, U)
        J = self.total_cost(X, U, x_goal, u_goal, Q, R, Qf)

        # Armijo line-search candidates
        alphas   = 0.5 ** np.arange(10)
        mu       = 1e-3    # Quu regularisation
        mu_max   = 1e6
        info     = {'converged': False, 'iterations': 0, 'cost': J}

        for i in range(max_iter):
            # ---- backward pass (retry with larger μ if Quu is singular) ----
            success = False
            for _ in range(10):
                try:
                    K, d, dV = self._backward_pass(
                        X, U, x_goal, u_goal, Q, R, Qf, mu)
                    success = True
                    break
                except np.linalg.LinAlgError:
                    mu = min(mu * 10.0, mu_max)

            if not success:
                break

            # ---- forward pass with Armijo line search ----
            updated = False
            for alpha in alphas:
                X_new, U_new = self._forward_pass(X, U, K, d, alpha)
                J_new        = self.total_cost(
                    X_new, U_new, x_goal, u_goal, Q, R, Qf)

                # Standard sufficient-decrease condition
                expected = alpha * dV[0] + alpha**2 * dV[1]
                if np.isfinite(J_new) and J_new < J - 1e-4 * abs(expected):
                    dJ    = J - J_new
                    X, U  = X_new, U_new
                    J     = J_new
                    mu    = max(mu / 5.0, 1e-6)
                    updated = True
                    break

            if verbose:
                print(f"  iLQR iter {i+1:3d}: J={J:.4e}  mu={mu:.1e}")

            info.update({'iterations': i + 1, 'cost': J})

            if not updated:
                info['converged'] = True
                break
            if dJ < tol:
                info['converged'] = True
                break

        return X, U, info
