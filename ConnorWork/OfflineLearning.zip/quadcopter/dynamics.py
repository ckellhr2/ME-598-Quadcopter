"""
Quadcopter rigid-body dynamics.

State  x  (12,): [x, y, z,  vx, vy, vz,  phi, theta, psi,  p, q, r]
Control u  (4,):  [f1, f2, f3, f4]  — individual motor thrusts [N]

Motor layout  (+ configuration, viewed from above, x = forward, y = left, z = up):

          f1  (front, CW)
           |
   f2 ----+---- f4  (left=f2, right=f4, both CCW)
           |
          f3  (back, CW)

Torques
  roll  τx = L*(f2 - f4)          left − right
  pitch τy = L*(f1 - f3)          front − back
  yaw   τz = km*(f1 - f2 + f3 - f4)  CW − CCW reaction
"""

import numpy as np


class QuadcopterParams:
    """Physical parameters for a small quadcopter (~500 g class)."""

    def __init__(
        self,
        m: float = 0.5,
        g: float = 9.81,
        Ixx: float = 4.9e-3,
        Iyy: float = 4.9e-3,
        Izz: float = 8.8e-3,
        L: float = 0.225,
        km: float = 0.07,
        f_min: float = 0.0,
        f_max: float = 3.0,
    ):
        self.m = m          # mass [kg]
        self.g = g          # gravitational acceleration [m/s²]
        self.Ixx = Ixx      # moment of inertia about body-x [kg·m²]
        self.Iyy = Iyy      # moment of inertia about body-y [kg·m²]
        self.Izz = Izz      # moment of inertia about body-z [kg·m²]
        self.L = L          # motor arm length [m]
        self.km = km        # drag-to-thrust ratio [m]
        self.f_min = f_min  # minimum thrust per motor [N]
        self.f_max = f_max  # maximum thrust per motor [N]

    @property
    def f_hover(self) -> float:
        """Thrust required per motor to hover."""
        return self.m * self.g / 4.0


# ---------------------------------------------------------------------------
# Kinematics helpers
# ---------------------------------------------------------------------------

def rotation_matrix(phi: float, theta: float, psi: float) -> np.ndarray:
    """
    ZYX (yaw-pitch-roll) rotation matrix mapping body → world frame.

    R = Rz(psi) · Ry(theta) · Rx(phi)
    """
    cphi, sphi = np.cos(phi), np.sin(phi)
    cth,  sth  = np.cos(theta), np.sin(theta)
    cpsi, spsi = np.cos(psi), np.sin(psi)

    return np.array([
        [cpsi*cth,  cpsi*sth*sphi - spsi*cphi,  cpsi*sth*cphi + spsi*sphi],
        [spsi*cth,  spsi*sth*sphi + cpsi*cphi,  spsi*sth*cphi - cpsi*sphi],
        [-sth,      cth*sphi,                    cth*cphi                 ],
    ])


# ---------------------------------------------------------------------------
# Continuous-time dynamics
# ---------------------------------------------------------------------------

def dynamics(state: np.ndarray, control: np.ndarray,
             params: QuadcopterParams) -> np.ndarray:
    """
    Continuous-time dynamics  ẋ = f(x, u).

    Returns the 12-element state derivative vector.
    """
    vx, vy, vz         = state[3],  state[4],  state[5]
    phi, theta, psi    = state[6],  state[7],  state[8]
    p, q, r            = state[9],  state[10], state[11]

    f1, f2, f3, f4 = control[0], control[1], control[2], control[3]

    T     = f1 + f2 + f3 + f4              # total thrust [N]
    tau_x = params.L  * (f2 - f4)          # roll  torque [N·m]
    tau_y = params.L  * (f1 - f3)          # pitch torque [N·m]
    tau_z = params.km * (f1 - f2 + f3 - f4)  # yaw   torque [N·m]

    # --- translational ---
    R = rotation_matrix(phi, theta, psi)
    thrust_world = R @ np.array([0.0, 0.0, T])

    d_pos = np.array([vx, vy, vz])
    d_vel = thrust_world / params.m + np.array([0.0, 0.0, -params.g])

    # --- Euler-angle kinematics (ZYX, singular at theta = ±90°) ---
    cphi, sphi = np.cos(phi), np.sin(phi)
    cth, sth   = np.cos(theta), np.sin(theta)
    cth_safe   = np.sign(cth) * max(abs(cth), 1e-6)   # guard gimbal lock
    tth        = sth / cth_safe

    d_phi   = p + (q * sphi + r * cphi) * tth
    d_theta = q * cphi - r * sphi
    d_psi   = (q * sphi + r * cphi) / cth_safe
    d_euler = np.array([d_phi, d_theta, d_psi])

    # --- rotational (Euler's equations) ---
    d_p = (tau_x + (params.Iyy - params.Izz) * q * r) / params.Ixx
    d_q = (tau_y + (params.Izz - params.Ixx) * p * r) / params.Iyy
    d_r = (tau_z + (params.Ixx - params.Iyy) * p * q) / params.Izz
    d_omega = np.array([d_p, d_q, d_r])

    return np.concatenate([d_pos, d_vel, d_euler, d_omega])


# ---------------------------------------------------------------------------
# Discrete-time integration
# ---------------------------------------------------------------------------

def rk4_step(state: np.ndarray, control: np.ndarray,
             dt: float, params: QuadcopterParams) -> np.ndarray:
    """Single 4th-order Runge–Kutta integration step."""
    f = lambda s: dynamics(s, control, params)
    k1 = f(state)
    k2 = f(state + 0.5 * dt * k1)
    k3 = f(state + 0.5 * dt * k2)
    k4 = f(state + dt * k3)
    return state + (dt / 6.0) * (k1 + 2.0*k2 + 2.0*k3 + k4)


# ---------------------------------------------------------------------------
# Numerical Jacobians of the discrete map
# ---------------------------------------------------------------------------

def linearize(
    state: np.ndarray,
    control: np.ndarray,
    dt: float,
    params: QuadcopterParams,
    eps: float = 1e-5,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Central-difference Jacobians of the discrete-time map x_{k+1} = F(x_k, u_k).

    Returns
      A  (n×n)  ∂F/∂x
      B  (n×m)  ∂F/∂u
    """
    n = state.shape[0]
    m = control.shape[0]

    A = np.empty((n, n))
    for i in range(n):
        e = np.zeros(n)
        e[i] = eps
        xp = rk4_step(state + e, control, dt, params)
        xm = rk4_step(state - e, control, dt, params)
        A[:, i] = (xp - xm) / (2.0 * eps)

    B = np.empty((n, m))
    for j in range(m):
        e = np.zeros(m)
        e[j] = eps
        xp = rk4_step(state, control + e, dt, params)
        xm = rk4_step(state, control - e, dt, params)
        B[:, j] = (xp - xm) / (2.0 * eps)

    return A, B
