"""
Offline optimizer for iLQR cost matrices.

Two methods are provided:
  'differential_evolution'  — scipy DE, robust, no gradient needed (default)
  'cma'                     — CMA-ES via the optional `cma` package

Both optimise the 28-element log-space parameter vector that encodes the
diagonal entries of Q (12), R (4), and Qf (12).

Log-space bounds (search region):

  Q           exp(-3) ~  0.05  ..  exp(7)  ~ 1097   (starting point: 8-180)
  R           exp(-6) ~  0.002 ..  exp(2)  ~  7.4   (starting point: 0.05)
  Qf          exp(-1) ~  0.37  ..  exp(10) ~ 22026  (starting point: 240-5400)
"""

from __future__ import annotations

import sys
import time
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
from typing import Callable, Optional

import numpy as np
from scipy.optimize import differential_evolution


# Parameter vector layout (28 elements)
_N_STATE = 12
_N_CTRL  = 4
_N_PARAM = 2 * _N_STATE + _N_CTRL   # 28

# Log-space search bounds per group
# Wide enough to contain the Julia starting point (Q up to 180, Qf up to 5400)
_BOUNDS_Q  = (-3.0,  7.0)   # exp(-3)~0.05  .. exp(7)~1097
_BOUNDS_R  = (-6.0,  2.0)   # exp(-6)~0.002 .. exp(2)~7.4
_BOUNDS_QF = (-1.0, 10.0)   # exp(-1)~0.37  .. exp(10)~22026

BOUNDS: list[tuple[float, float]] = (
    [_BOUNDS_Q]  * _N_STATE +
    [_BOUNDS_R]  * _N_CTRL  +
    [_BOUNDS_QF] * _N_STATE
)


class MatrixOptimizer:
    """
    Optimize diagonal Q, R, Qf for iLQR via gradient-free search.

    Usage
    -----
    >>> opt = MatrixOptimizer()
    >>> result = opt.optimize(objective_fn, method='differential_evolution')
    >>> Q, R, Qf = build_matrices(result['x'])
    """

    def __init__(
        self,
        bounds: list[tuple[float, float]] | None = None,
    ):
        self.bounds = bounds if bounds is not None else BOUNDS
        assert len(self.bounds) == _N_PARAM

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def optimize(
        self,
        objective: Callable[[np.ndarray], float],
        method: str = 'differential_evolution',
        maxiter: int = 50,
        n_pop: int = 28,
        seed: int = 0,
        x0: Optional[np.ndarray] = None,
        workers: int = 1,
        verbose: bool = True,
    ) -> dict:
        """
        Minimize ``objective(params_vec)`` over the 28-element parameter space.

        Parameters
        ----------
        objective : callable mapping (28,) ndarray → scalar float
        method    : 'differential_evolution' or 'cma'
        maxiter   : maximum number of optimizer generations / iterations
        n_pop     : *absolute* population size (individuals per generation).
                    scipy's popsize multiplier is computed as max(1, n_pop//28).
                    Minimum effective population is 28 (one per parameter).
                    Rule of thumb: 28 (fast) … 56 (balanced) … 140 (thorough).
        seed      : random seed for reproducibility
        x0        : initial parameter vector (optional; used as seed for CMA)
        workers   : parallel workers for DE (-1 = all CPU cores)
        verbose   : print progress

        Returns
        -------
        dict with keys:
          'x'       best parameter vector  (28,)
          'fun'     best objective value
          'nit'     iterations performed
          'success' bool
          'message' status string
        """
        if method == 'differential_evolution':
            return self._run_de(objective, maxiter, n_pop, seed,
                                workers, verbose)
        elif method == 'cma':
            return self._run_cma(objective, x0, maxiter, verbose)
        else:
            raise ValueError(f"Unknown method '{method}'. "
                             "Choose 'differential_evolution' or 'cma'.")

    # ------------------------------------------------------------------
    # Differential evolution
    # ------------------------------------------------------------------

    def _run_de(
        self,
        objective: Callable,
        maxiter: int,
        n_pop: int,
        seed: int,
        workers: int,
        verbose: bool,
    ) -> dict:
        # scipy popsize is a multiplier on ndim; compute to hit n_pop closely
        pop_mult   = max(1, n_pop // _N_PARAM)
        actual_pop = pop_mult * _N_PARAM
        if verbose:
            print(f"  DE: {actual_pop} individuals/gen  "
                  f"(n_pop={n_pop}, scipy popsize={pop_mult}x{_N_PARAM})")

        start = time.time()
        gen_history: list[float] = []

        def callback(xk, convergence):
            # re-evaluate best individual once per generation for logging
            # (1 extra eval per gen is negligible vs population cost)
            elapsed = time.time() - start
            cost = float(objective(xk))
            gen_history.append(cost)
            if verbose:
                print(f"  [DE  gen {len(gen_history):3d}]  "
                      f"best={cost:.4e}  "
                      f"convergence={convergence:.3f}  "
                      f"elapsed={elapsed:.1f}s")
            return False

        result = differential_evolution(
            objective,          # pass directly — must be picklable for workers>1
            bounds=self.bounds,
            maxiter=maxiter,
            popsize=pop_mult,
            seed=seed,
            mutation=(0.5, 1.0),
            recombination=0.9,
            strategy='best1bin',
            tol=1e-5,
            polish=False,           # polishing via L-BFGS-B is very slow here
            updating='deferred',
            workers=workers,
            callback=callback,
        )

        return {
            'x':       result.x,
            'fun':     float(result.fun),
            'nit':     result.nit,
            'success': result.success,
            'message': result.message,
            'history': gen_history,
        }

    # ------------------------------------------------------------------
    # CMA-ES  (requires `pip install cma`)
    # ------------------------------------------------------------------

    def _run_cma(
        self,
        objective: Callable,
        x0: Optional[np.ndarray],
        maxiter: int,
        verbose: bool,
    ) -> dict:
        try:
            import cma
        except ImportError as e:
            raise ImportError(
                "CMA-ES requires the `cma` package.  "
                "Install it with:  pip install cma"
            ) from e

        if x0 is None:
            x0 = np.array([(lo + hi) / 2 for lo, hi in self.bounds])

        lo = [b[0] for b in self.bounds]
        hi = [b[1] for b in self.bounds]

        opts = {
            'maxiter':  maxiter,
            'bounds':   [lo, hi],
            'verbose':  1 if verbose else -9,
            'seed':     0,
        }

        es      = cma.CMAEvolutionStrategy(x0, 0.5, opts)
        history: list[float] = []

        while not es.stop():
            solutions = es.ask()
            fitnesses  = [objective(np.array(x)) for x in solutions]
            es.tell(solutions, fitnesses)
            history.append(float(es.result.fbest))
            if verbose:
                es.disp()

        return {
            'x':       np.array(es.result.xbest),
            'fun':     float(es.result.fbest),
            'nit':     es.result.iterations,
            'success': True,
            'message': 'CMA-ES completed',
            'history': history,
        }
