"""
Performance evaluation for Q, R, Qf parameter vectors.

The 28-element parameter vector is laid out as:

  params_vec = [ log(q_0)..log(q_11),   <- 12 diagonal Q entries
                 log(r_0)..log(r_3),     <-  4 diagonal R entries
                 log(qf_0)..log(qf_11) ] <- 12 diagonal Qf entries

Working in log-space guarantees positive-definiteness and gives the
optimizer a well-conditioned, unbounded search space.
"""

from __future__ import annotations

import numpy as np
from typing import Any

from quadcopter.dynamics import QuadcopterParams
from controllers.ilqr import iLQR

# Index slices for the flat parameter vector
_IDX_Q  = slice(0,  12)
_IDX_R  = slice(12, 16)
_IDX_QF = slice(16, 28)


# ---------------------------------------------------------------------------
# Parameter vector  ↔  matrices
# ---------------------------------------------------------------------------

def build_matrices(
    params_vec: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Convert flat log-space parameter vector → (Q, R, Qf) diagonal matrices.

    Raises ValueError if params_vec has the wrong length (expected 28).
    """
    if params_vec.shape[0] != 28:
        raise ValueError(f"Expected 28 parameters, got {params_vec.shape[0]}")

    Q  = np.diag(np.exp(params_vec[_IDX_Q]))
    R  = np.diag(np.exp(params_vec[_IDX_R]))
    Qf = np.diag(np.exp(params_vec[_IDX_QF]))
    return Q, R, Qf


def matrices_to_params(
    Q: np.ndarray,
    R: np.ndarray,
    Qf: np.ndarray,
) -> np.ndarray:
    """Inverse of build_matrices: extract log-diagonal entries."""
    return np.concatenate([
        np.log(np.diag(Q)),
        np.log(np.diag(R)),
        np.log(np.diag(Qf)),
    ])


def default_params_vec(params: QuadcopterParams | None = None) -> np.ndarray:
    """
    Starting-point parameter vector matching the known-good Julia iLQR weights:

        Q  = diag([180, 180, 80, 35, 35, 25, 35, 35, 20, 8, 8, 8])
        R  = 0.05 * I(4)
        Qf = 30 * Q

    State order:  x y z  vx vy vz  phi theta psi  p q r
    """
    q_diag = np.array([
        180.0, 180.0,  80.0,   # position   x y z
         35.0,  35.0,  25.0,   # velocity   vx vy vz
         35.0,  35.0,  20.0,   # angles     phi theta psi
          8.0,   8.0,   8.0,   # ang. rates p q r
    ])
    r_diag = np.array([0.05, 0.05, 0.05, 0.05])
    qf_diag = 30.0 * q_diag    # Qf = 30 * Q

    return matrices_to_params(
        np.diag(q_diag), np.diag(r_diag), np.diag(qf_diag))


# ---------------------------------------------------------------------------
# Single-scenario evaluator
# ---------------------------------------------------------------------------

def evaluate_performance(
    params_vec: np.ndarray,
    scenario: dict[str, Any],
    quad_params: QuadcopterParams,
    dt: float = 0.02,
    N: int = 150,
    ilqr_max_iter: int = 60,
    w_pos: float = 1.0,
    w_vel: float = 0.1,
    w_ctrl: float = 0.01,
    w_traj: float = 0.5,
) -> float:
    """
    Run iLQR with the given parameter vector and return a scalar performance cost.

    Performance metric (lower = better):

      J_perf = w_pos  * ‖x_N[:3] − x_g[:3]‖²               (terminal position error)
             + w_vel  * ‖x_N[3:6]‖²                          (terminal velocity)
             + w_ctrl * mean_k( ‖u_k‖² )                      (mean control effort)
             + w_traj * mean_k( ‖x_k[:3] − x_g[:3]‖² )       (running position error)

    The w_traj term explicitly scores mid-flight position tracking, ensuring
    Q (which governs the running cost in iLQR) is meaningfully exercised by
    the optimizer rather than being driven toward zero.

    A large penalty (1e6) is returned on numerical failure.

    Parameters
    ----------
    params_vec    : 28-element log-space parameter vector
    scenario      : dict with keys:
                      'x0'     initial state  (12,)
                      'x_goal' goal state     (12,)
    quad_params   : QuadcopterParams instance
    dt, N         : time step and horizon
    ilqr_max_iter : max iLQR iterations per call
    w_pos         : weight on terminal position error
    w_vel         : weight on terminal velocity
    w_ctrl        : weight on mean control effort
    w_traj        : weight on mean running position error (encourages Q tuning)
    """
    try:
        Q, R, Qf = build_matrices(params_vec)
    except (ValueError, FloatingPointError):
        return 1e6

    x0     = scenario['x0']
    x_goal = scenario['x_goal']
    u_goal = np.full(4, quad_params.f_hover)

    controller = iLQR(quad_params, dt, N)

    try:
        X, U, info = controller.solve(
            x0, x_goal, u_goal, Q, R, Qf,
            max_iter=ilqr_max_iter,
            verbose=False,
        )

        if not np.all(np.isfinite(X)) or not np.all(np.isfinite(U)):
            return 1e6

        # Terminal costs
        pos_error   = np.linalg.norm(X[-1, :3] - x_goal[:3]) ** 2
        vel_error   = np.linalg.norm(X[-1, 3:6]) ** 2

        # Running costs  (over all N+1 states including x0)
        traj_error  = float(np.mean(
            np.sum((X[:, :3] - x_goal[:3]) ** 2, axis=1)
        ))
        ctrl_effort = float(np.mean(np.sum(U ** 2, axis=1)))

        return (w_pos  * pos_error
                + w_vel  * vel_error
                + w_ctrl * ctrl_effort
                + w_traj * traj_error)

    except Exception:
        return 1e6


# ---------------------------------------------------------------------------
# Multi-scenario evaluator (average over training scenarios)
# ---------------------------------------------------------------------------

def evaluate_scenarios(
    params_vec: np.ndarray,
    scenarios: list[dict],
    quad_params: QuadcopterParams,
    **kwargs,
) -> float:
    """Average performance across all training scenarios."""
    costs = [
        evaluate_performance(params_vec, sc, quad_params, **kwargs)
        for sc in scenarios
    ]
    return float(np.mean(costs))


# ---------------------------------------------------------------------------
# Picklable objective wrapper  (required for multiprocessing / workers > 1)
# ---------------------------------------------------------------------------

class ScenarioObjective:
    """
    Module-level callable wrapping evaluate_scenarios.

    Defined at module scope so Python's multiprocessing can pickle it when
    scipy differential_evolution spawns worker processes (workers != 1).

    Usage
    -----
    >>> obj = ScenarioObjective(scenarios, quad_params, dt=0.02, N=150,
    ...                         ilqr_max_iter=60, w_pos=1.0, w_vel=0.1,
    ...                         w_ctrl=0.01)
    >>> cost = obj(params_vec)
    """

    def __init__(
        self,
        scenarios: list[dict],
        quad_params: QuadcopterParams,
        dt: float = 0.02,
        N: int = 150,
        ilqr_max_iter: int = 60,
        w_pos: float = 1.0,
        w_vel: float = 0.1,
        w_ctrl: float = 0.01,
        w_traj: float = 0.5,
    ):
        self.scenarios      = scenarios
        self.quad_params    = quad_params
        self.dt             = dt
        self.N              = N
        self.ilqr_max_iter  = ilqr_max_iter
        self.w_pos          = w_pos
        self.w_vel          = w_vel
        self.w_ctrl         = w_ctrl
        self.w_traj         = w_traj

    def __call__(self, params_vec: np.ndarray) -> float:
        return evaluate_scenarios(
            params_vec,
            self.scenarios,
            self.quad_params,
            dt=self.dt,
            N=self.N,
            ilqr_max_iter=self.ilqr_max_iter,
            w_pos=self.w_pos,
            w_vel=self.w_vel,
            w_ctrl=self.w_ctrl,
            w_traj=self.w_traj,
        )
