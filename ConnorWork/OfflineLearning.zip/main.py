"""
Offline learning for iLQR quadcopter cost matrices.

Workflow
--------
1.  Define training scenarios  (initial state + goal).
2.  Define objective: average iLQR performance across scenarios.
3.  Run differential-evolution (or CMA-ES) to tune Q, R, Qf diagonals.
4.  Evaluate the optimised controller on a test scenario.
5.  Save results and plot.

Quick start
-----------
    python main.py                        # full run  (~45-90 min, 1 core)
    python main.py --workers -1           # parallel eval on all CPU cores
    python main.py --quick                # 3 gens / 1 scenario  (~3-5 min)
    python main.py --method cma           # CMA-ES instead of DE
    python main.py --maxiter 20 --n-pop 28  # custom budget
"""

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

# Ensure UTF-8 output on Windows terminals that default to cp1252
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

from quadcopter  import QuadcopterParams
from controllers import iLQR
from learning    import (MatrixOptimizer, build_matrices,
                          default_params_vec, evaluate_scenarios,
                          ScenarioObjective)
from utils       import plot_trajectory, plot_learning_curve


# ---------------------------------------------------------------------------
# Training scenario library
# ---------------------------------------------------------------------------

def make_scenarios(quad: QuadcopterParams) -> list[dict]:
    """
    A small set of point-to-point flights that cover different axes,
    starting from hover at various altitudes.
    """
    def hover(z: float) -> np.ndarray:
        s = np.zeros(12)
        s[2] = z
        return s

    def goal(x: float, y: float, z: float) -> np.ndarray:
        g = np.zeros(12)
        g[:3] = [x, y, z]
        return g

    return [
        # fly +x
        {'x0': hover(1.0), 'x_goal': goal(3.0, 0.0, 1.0)},
        # fly +y  and climb
        {'x0': hover(0.5), 'x_goal': goal(0.0, 2.0, 2.0)},
        # diagonal 3-D move
        {'x0': hover(1.0), 'x_goal': goal(2.0, 2.0, 3.0)},
        # descend while moving laterally
        {'x0': hover(3.0), 'x_goal': goal(1.5, 0.0, 1.5)},
    ]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description='Offline iLQR tuning')
    parser.add_argument('--method', choices=['differential_evolution', 'cma'],
                        default='differential_evolution')
    parser.add_argument('--maxiter',  type=int,   default=40)
    parser.add_argument('--n-pop',    type=int,   default=28,
                        help='Absolute population size (min 28 = 1×ndim)')
    parser.add_argument('--workers',  type=int,   default=1,
                        help='Parallel workers for DE (-1 = all cores)')
    parser.add_argument('--dt',       type=float, default=0.02,
                        help='Simulation time step [s]')
    parser.add_argument('--horizon',  type=int,   default=150,
                        help='iLQR horizon steps')
    parser.add_argument('--ilqr-iter', type=int,  default=60,
                        help='Max iLQR iterations per objective eval')
    parser.add_argument('--out',      type=str,   default='results',
                        help='Output directory for results/plots')
    parser.add_argument('--quick', action='store_true',
                        help='Smoke-test: 3 generations, 1 scenario, short horizon')
    args = parser.parse_args()

    if args.quick:
        args.maxiter   = 3
        args.n_pop     = 28   # minimum: 28 individuals per generation
        args.horizon   = 80
        args.ilqr_iter = 20

    out_dir = Path(args.out)
    out_dir.mkdir(exist_ok=True)

    # ------------------------------------------------------------------ #
    quad     = QuadcopterParams()
    scenarios = make_scenarios(quad)
    if args.quick:
        scenarios = scenarios[:1]

    print("=" * 60)
    print("  Offline iLQR tuning  —  quadcopter (12 states, 4 inputs)")
    print("=" * 60)
    print(f"  Optimizer : {args.method}")
    print(f"  Max iters : {args.maxiter}  |  Pop size: {args.n_pop}")
    print(f"  dt={args.dt} s  |  N={args.horizon}  "
          f"|  T={args.dt * args.horizon:.2f} s horizon")
    print(f"  Scenarios : {len(scenarios)}")
    print(f"  Workers   : {args.workers}")
    print()

    # ------------------------------------------------------------------ #
    # Objective function  — module-level class so multiprocessing can pickle it
    # ------------------------------------------------------------------ #
    objective = ScenarioObjective(
        scenarios     = scenarios,
        quad_params   = quad,
        dt            = args.dt,
        N             = args.horizon,
        ilqr_max_iter = args.ilqr_iter,
        w_pos         = 1.0,    # terminal position error
        w_vel         = 0.1,    # terminal velocity
        w_ctrl        = 0.01,   # mean control effort
        w_traj        = 0.5,    # mean running position error (exercises Q)
    )

    # Baseline: evaluate default heuristic matrices
    x0_default = default_params_vec(quad)
    J_default  = objective(x0_default)
    print(f"  Baseline (heuristic Q/R/Qf) cost: {J_default:.4e}\n")

    # ------------------------------------------------------------------ #
    # Optimisation
    # ------------------------------------------------------------------ #
    optimizer = MatrixOptimizer()
    t0        = time.time()

    result = optimizer.optimize(
        objective,
        method=args.method,
        maxiter=args.maxiter,
        n_pop=args.n_pop,
        x0=x0_default,
        workers=args.workers,
        verbose=True,
    )

    elapsed = time.time() - t0
    print(f"\n{'=' * 60}")
    n_evals = result['nit'] * 28 + 28   # approx: gens * pop + initial pop
    print(f"  Optimisation finished in {elapsed:.1f} s  "
          f"(~{n_evals} objective evaluations)")
    print(f"  Best cost : {result['fun']:.4e}  "
          f"(Δ = {result['fun'] - J_default:+.4e} vs baseline)")
    print(f"  Converged : {result['success']}")
    print(f"  Message   : {result['message']}")

    # ------------------------------------------------------------------ #
    # Extract and display optimised matrices
    # ------------------------------------------------------------------ #
    Q_opt, R_opt, Qf_opt = build_matrices(result['x'])

    state_names = ['x','y','z','vx','vy','vz','φ','θ','ψ','p','q','r']
    print("\n  Optimised Q  (diagonal):")
    for name, val in zip(state_names, np.diag(Q_opt)):
        print(f"    {name:>4s}  {val:.4f}")
    print("  Optimised R  (diagonal):", np.round(np.diag(R_opt), 5))
    print("  Optimised Qf (diagonal):")
    for name, val in zip(state_names, np.diag(Qf_opt)):
        print(f"    {name:>4s}  {val:.4f}")

    # ------------------------------------------------------------------ #
    # Save results
    # ------------------------------------------------------------------ #
    results_payload = {
        'params_vec':   result['x'].tolist(),
        'Q_diag':       np.diag(Q_opt).tolist(),
        'R_diag':       np.diag(R_opt).tolist(),
        'Qf_diag':      np.diag(Qf_opt).tolist(),
        'best_cost':    result['fun'],
        'baseline_cost': J_default,
        'history':      result.get('history', []),
        'method':       args.method,
        'elapsed_s':    elapsed,
    }
    results_file = out_dir / 'optimised_matrices.json'
    with open(results_file, 'w') as fh:
        json.dump(results_payload, fh, indent=2)
    print(f"\n  Results saved → {results_file}")

    # ------------------------------------------------------------------ #
    # Learning curve
    # ------------------------------------------------------------------ #
    if result.get('history'):
        lc_path = str(out_dir / 'learning_curve.png')
        plot_learning_curve(result['history'], save_path=lc_path)

    # ------------------------------------------------------------------ #
    # Detailed test rollout with optimised matrices
    # ------------------------------------------------------------------ #
    print("\n  Running detailed test rollout …")
    test_scenario = {
        'x0':     np.array([0., 0., 0.5,  0., 0., 0.,  0., 0., 0.,  0., 0., 0.]),
        'x_goal': np.concatenate([[3.0, 2.0, 2.5], np.zeros(9)]),
    }

    u_goal     = np.full(4, quad.f_hover)
    controller = iLQR(quad, args.dt, args.horizon)

    X_opt, U_opt, info_opt = controller.solve(
        test_scenario['x0'],
        test_scenario['x_goal'],
        u_goal,
        Q_opt, R_opt, Qf_opt,
        max_iter=100,
        verbose=True,
    )

    pos_err = np.linalg.norm(X_opt[-1, :3] - test_scenario['x_goal'][:3])
    print(f"\n  Final position : {X_opt[-1, :3].round(3)}")
    print(f"  Goal position  : {test_scenario['x_goal'][:3]}")
    print(f"  Position error : {pos_err:.4f} m")
    print(f"  Control effort : {np.mean(np.sum(U_opt**2, axis=1)):.4f}")
    print(f"  iLQR converged : {info_opt['converged']}  "
          f"({info_opt['iterations']} iters,  cost={info_opt['cost']:.4e})")

    traj_path = str(out_dir / 'trajectory_optimised.png')
    plot_trajectory(X_opt, U_opt, test_scenario['x_goal'],
                    args.dt, title='Test rollout — optimised matrices',
                    save_path=traj_path)

    # ------------------------------------------------------------------ #
    # Comparison: baseline matrices on the same test
    # ------------------------------------------------------------------ #
    Q_base, R_base, Qf_base = build_matrices(x0_default)
    X_base, U_base, info_base = controller.solve(
        test_scenario['x0'],
        test_scenario['x_goal'],
        u_goal,
        Q_base, R_base, Qf_base,
        max_iter=100,
    )

    pos_err_base = np.linalg.norm(X_base[-1, :3] - test_scenario['x_goal'][:3])
    print(f"\n  Baseline position error : {pos_err_base:.4f} m   "
          f"(optimised: {pos_err:.4f} m)")

    traj_base_path = str(out_dir / 'trajectory_baseline.png')
    plot_trajectory(X_base, U_base, test_scenario['x_goal'],
                    args.dt, title='Test rollout — baseline matrices',
                    save_path=traj_base_path)

    print("\nDone.")


if __name__ == '__main__':
    main()
